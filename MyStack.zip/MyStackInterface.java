
interface MyStackInterface<T> {
    boolean isEmpty();
    void push (T newvalue);
    T pop();
    T top();
}
